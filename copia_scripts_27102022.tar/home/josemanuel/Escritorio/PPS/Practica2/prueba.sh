#!/bin/bash
while true; do
    echo "Elige una opción"
    echo " 1)Sumar
 2)Restar
 3)Multiplicar
 4)Dividir
 5)Salir"

    # Leemos la opción que ha elegido y llamamos a la función correspondiente
    read opc
    case $opc in
    1)
        operacionSumar
        ;;
    2)
        operacionRestar
        ;;
    3)
        operacionMultiplicar
        ;;
    4)
        operacionDivision
        ;;
    5)
        echo "Has salido de la calculadora."
        exit
        ;;
    *)
        # Si no se ha elegido una opción válida
        echo "Elige una opción válida. Si quieres salir, pulsa 5"
        sleep 1s
        echo ""
        ;;
    esac
done